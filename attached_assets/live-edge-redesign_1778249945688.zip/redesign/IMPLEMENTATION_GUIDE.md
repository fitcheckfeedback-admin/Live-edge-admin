# Live Edge Engine — Redesign Implementation Guide

## What Changed & Why

### Design Direction
"Bloomberg Terminal meets Nike Training" — deep navy base, electric green (#00ff87) as the signature 
accent, layered surface depth, tight typography, and data-dense cards that breathe.

---

## Files to Replace

Copy each file from this redesign folder into your project at the exact same path:

| Redesign File | Replace In Your Project |
|---|---|
| `constants/colors.ts` | `artifacts/mobile/constants/colors.ts` |
| `components/AppHeader.tsx` | `artifacts/mobile/components/AppHeader.tsx` |
| `components/PlayerCard.tsx` | `artifacts/mobile/components/PlayerCard.tsx` |
| `app/(tabs)/_layout.tsx` | `artifacts/mobile/app/(tabs)/_layout.tsx` |
| `app/(tabs)/index.tsx` | `artifacts/mobile/app/(tabs)/index.tsx` |
| `app/(tabs)/games.tsx` | `artifacts/mobile/app/(tabs)/games.tsx` |
| `app/(tabs)/slip.tsx` | `artifacts/mobile/app/(tabs)/slip.tsx` |
| `app/(tabs)/more.tsx` | `artifacts/mobile/app/(tabs)/more.tsx` |

---

## Key Design Changes Per Screen

### 🎨 Colors (`colors.ts`)
- Deeper background: `#060d1a` → ultra-dark navy
- Brighter primary: `#00ff87` → electric green with glow variants
- Added: `primaryGlow`, `cardBorderActive`, `backgroundElevated`, `backgroundSurface`
- Added: `mutedForegroundBright` for secondary text that still reads
- Over/Under now use `#00e676` and `#ff4d4d` (more saturated, punchier)

### 📱 AppHeader
- Added 2px green accent line under the logo mark
- Logo icon changed to `zap` (more on-brand for "Edge")
- Added `subtitle` prop — used to show date/context text under the title
- Refresh button uses `backgroundSurface` fill for depth
- Live pill now says "{N} LIVE" in caps for clarity

### 🃏 PlayerCard (biggest change)
- **EdgeBar** — visual progress bar showing edge score 0–10 in the card body
- Strong plays get a green dot indicator on the avatar
- `isStrong` detection (winProb ≥ 65) drives subtle green border glow
- Top meta row: sport tag + matchup + time all in one line
- Side pill moved to right column beside WinProbBadge
- "BEST PICK" row at bottom is cleaner — line number, prop type, chevron
- In-slip tag shows bookmark icon + count (was text only)

### ⚡ Edge Board (index.tsx)
- Stats hero card with green top stripe and 4 stat tiles
- Section label "RANKED BY EDGE SCORE" with player count
- Header subtitle shows today's date
- Empty state uses `zap-off` icon

### 🏀 Games (games.tsx)
- Home/away winner detection — winning team name is bold, losing team is muted
- Scores use `Inter_700Bold` for leader, `Inter_600SemiBold` for trailer
- Divider between header row and team rows for cleaner scanability
- Section headers now show game count badge
- "Last update" time moved to a dot + text row under filter

### 🔖 My Slip (slip.tsx)
- **ProbabilityRing** — circular ring showing avg win prob with glow
- Pick rows have a colored left stripe (green = over, red = under)
- Remove button is now an X icon in a small square (less destructive looking)
- "Clear all" button is now red-tinted, not just outlined
- Empty state is vertically centered

### 📋 More (more.tsx)
- Stats strip matches index.tsx style (with green top stripe)
- Each menu item has a unique accent color (green, amber, blue, purple, slate)
- Cards feel more premium with colored icon blocks per section
- Lounge card separated at bottom

---

## New `AppHeader` `subtitle` Prop

The header now accepts an optional subtitle. Use it across all screens:

```tsx
<AppHeader
  title="Edge Board"
  subtitle={todayLabel()}   // ← new
  liveCount={liveCount}
  onRefresh={refetch}
  refreshing={isRefetching}
/>
```

---

## Colors You Can Now Use

```ts
colors.backgroundElevated    // tab bar bg
colors.backgroundSurface     // input/button fills  
colors.primaryGlow           // rgba green glow bg
colors.primaryGlowStrong     // stronger glow
colors.cardBorderActive      // green-tinted border for selected states
colors.mutedForegroundBright // readable secondary text (#94a3b8)
colors.live                  // same as primary, semantic alias
colors.liveGlow              // live indicator glow
```

---

## No Breaking Changes

All component APIs are backward compatible. Existing screens (live-edge, alerts, 
track-record, results, sources) will inherit the new colors automatically just 
from replacing `colors.ts`. No other changes needed for those screens to look better.

---

## Optional Next Steps

1. **Sport filter** — pill style to match the new card aesthetic
2. **PlayerSheet** — the detail bottom sheet could use the same card patterns
3. **SkeletonCard** — update to use `backgroundSurface` for shimmer base
4. **Alerts screen** — add severity color coding using new `over`/`under`/`accent` tokens
5. **Track Record** — green/red hit rate bars using the EdgeBar pattern
