# propsGenerator.ts — Patch Instructions

Apply these targeted changes to `artifacts/api-server/src/lib/propsGenerator.ts`.
Do NOT replace the whole file — it is 1100+ lines. Apply each patch individually.

---

## Patch 1 — Reduce props cache TTL from 60s to 30s

Find:
```ts
const PROPS_TTL = 60 * 1000;
```

Replace with:
```ts
// Reduced from 60s → 30s so data stays fresh during active game windows
const PROPS_TTL = 30 * 1000;
```

---

## Patch 2 — Exclude final games from props generation

In `getTodayProps()`, find this line (around line 980):
```ts
const eligible = games.filter((g) => g.homeTeam.id && g.awayTeam.id);
```

Replace with:
```ts
// Exclude finished games — no point generating props for games that ended
const eligible = games.filter(
  (g) => g.homeTeam.id && g.awayTeam.id && g.status !== "final",
);
```

---

## Patch 3 — Sort live edges: Strong recommendations first

In `getLiveEdges()`, find the final sort+slice (around line 1140):
```ts
edges.sort((a, b) => Math.abs(b.liveEdgePercent) - Math.abs(a.liveEdgePercent));
return edges.slice(0, 12);
```

Replace with:
```ts
// Sort: Strong recommendations first, then by absolute edge magnitude
const recRank = (r: string) =>
  r.includes("Strong") ? 0 : r.includes("Lean") ? 1 : 2;
edges.sort((a, b) => {
  const rankDiff = recRank(a.liveRecommendation) - recRank(b.liveRecommendation);
  if (rankDiff !== 0) return rankDiff;
  return Math.abs(b.liveEdgePercent) - Math.abs(a.liveEdgePercent);
});
// Cap at 15 (was 12) — more live edges visible during busy game windows
return edges.slice(0, 15);
```

---

## Patch 4 — Auto-cleanup stale prop alerts in app.ts

Add to `artifacts/api-server/src/app.ts` after the grader interval:

```ts
// Nightly cleanup: remove alerts older than 24h so the DB doesn't bloat.
// Runs once at startup then every 6 hours.
async function cleanStaleAlerts() {
  try {
    const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000);
    await db.delete(alertsTable).where(lt(alertsTable.createdAt, cutoff));
    logger.info("Stale alerts cleaned");
  } catch (err) {
    logger.warn({ err: String(err) }, "stale alert cleanup failed");
  }
}
setTimeout(cleanStaleAlerts, 5_000);
setInterval(cleanStaleAlerts, 6 * 60 * 60 * 1000);
```

Also add these imports at the top of `app.ts`:
```ts
import { db, alertsTable } from "@workspace/db";
import { lt } from "drizzle-orm";
```
