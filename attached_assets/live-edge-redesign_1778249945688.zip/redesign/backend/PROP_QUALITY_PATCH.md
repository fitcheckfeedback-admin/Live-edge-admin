# Prop Quality Upgrade — propsGenerator.ts Patch

Apply each patch in order. These are all targeted changes — do NOT rewrite
the whole file. Use find/replace in your editor.

---

## PATCH 1 — Tighten prop templates to real-market offerings only

### NBA Templates
The current templates include low-value props (Blocks for C, Rebounds for SG)
that rarely appear on PrizePicks. Replace `NBA_TEMPLATES_BY_POS` with:

```ts
const NBA_TEMPLATES_BY_POS: Record<string, PropTemplate[]> = {
  PG: [
    { type: "Points",           unit: "pts",     weight: 1.0 },
    { type: "Assists",          unit: "ast",     weight: 1.0 },
    { type: "Pts+Reb+Ast",      unit: "PRA",     weight: 0.9 },
    { type: "3-Pointers Made",  unit: "3PM",     weight: 0.8 },
    { type: "Points + Assists", unit: "pts+ast", weight: 0.7 },
  ],
  SG: [
    { type: "Points",           unit: "pts",     weight: 1.0 },
    { type: "3-Pointers Made",  unit: "3PM",     weight: 0.9 },
    { type: "Pts+Reb+Ast",      unit: "PRA",     weight: 0.8 },
    { type: "Rebounds",         unit: "reb",     weight: 0.6 },
  ],
  SF: [
    { type: "Points",              unit: "pts",     weight: 1.0 },
    { type: "Rebounds",            unit: "reb",     weight: 0.9 },
    { type: "Pts+Reb+Ast",         unit: "PRA",     weight: 0.9 },
    { type: "Points + Rebounds",   unit: "pts+reb", weight: 0.7 },
  ],
  PF: [
    { type: "Points",            unit: "pts",     weight: 0.9 },
    { type: "Rebounds",          unit: "reb",     weight: 1.0 },
    { type: "Pts+Reb+Ast",       unit: "PRA",     weight: 0.9 },
    { type: "Points + Rebounds", unit: "pts+reb", weight: 0.8 },
  ],
  C: [
    { type: "Points",            unit: "pts",     weight: 0.9 },
    { type: "Rebounds",          unit: "reb",     weight: 1.0 },
    { type: "Points + Rebounds", unit: "pts+reb", weight: 0.9 },
    { type: "Pts+Reb+Ast",       unit: "PRA",     weight: 0.7 },
  ],
  G: [
    { type: "Points",           unit: "pts",     weight: 1.0 },
    { type: "Assists",          unit: "ast",     weight: 0.9 },
    { type: "3-Pointers Made",  unit: "3PM",     weight: 0.7 },
  ],
  F: [
    { type: "Points",   unit: "pts", weight: 1.0 },
    { type: "Rebounds", unit: "reb", weight: 0.9 },
    { type: "Pts+Reb+Ast", unit: "PRA", weight: 0.8 },
  ],
};
```

### MLB Batter Templates
Remove `Stolen Bases`, `Singles`, `Doubles`, `Hitter Strikeouts` — not
standard PrizePicks offerings. Replace `MLB_BATTER_TEMPLATES` with:

```ts
const MLB_BATTER_TEMPLATES: PropTemplate[] = [
  { type: "Total Bases",    unit: "TB",      weight: 1.0 },
  { type: "Hits+Runs+RBIs", unit: "H+R+RBI", weight: 1.0 },
  { type: "Hits",           unit: "hits",    weight: 0.9 },
  { type: "RBIs",           unit: "RBI",     weight: 0.8 },
  { type: "Runs",           unit: "runs",    weight: 0.7 },
  { type: "Home Runs",      unit: "HR",      weight: 0.6 },
  { type: "Walks",          unit: "BB",      weight: 0.5 },
];
```

---

## PATCH 2 — Raise the minimum volume gate for showing a prop

Find this block in `buildPropFromRealData` (around line 555):
```ts
  if (last10.length >= 5 && Math.max(...last10) === 0) return null;
```

Replace with:
```ts
  // Gate 1: Player has zero production across last 10 games → skip entirely.
  if (last10.length >= 5 && Math.max(...last10) === 0) return null;

  // Gate 2: Minimum sample — need at least 5 real data points to model a line.
  if (last10.length < 5) return null;

  // Gate 3: Minimum line value — props below 0.5 are not offered on real apps.
  // chooseBalancedLine floors at 0.5 already, but this ensures upstream
  // zero-production stats (e.g. a batter with 0 HRs last 10) don't slip through.
  const tentativeMax = Math.max(...last10);
  if (tentativeMax < 0.5) return null;
```

---

## PATCH 3 — Improve the win probability formula

The current formula treats hitRate10 as the sole anchor. We improve it by:
1. Weighting L5 hit rate more heavily (recency matters more)
2. Applying a consistency penalty that actually lowers the floor for erratic players
3. Clamping stronger (32–88 instead of 28–92) — 92% confidence claims are unrealistic

Find this block (around line 610):
```ts
  const sideHitRate = isOver ? hitRate10 : 1 - hitRate10;
  const consistencyWeight = 0.5 + consistency * 0.5;
  let winProbRaw = 50 + (sideHitRate * 100 - 50) * consistencyWeight;
  if ((trend === "up" && isOver) || (trend === "down" && !isOver)) winProbRaw += 3;
  if ((trend === "down" && isOver) || (trend === "up" && !isOver)) winProbRaw -= 3;

  const factors: PropFactors = {
    weather: input.weatherFactor,
    opponent: input.opponentFactor,
    h2h: input.h2hFactor,
  };
  const factorImpact = (factors.weather?.impact ?? 0) + factors.opponent.impact + factors.h2h.impact;
  const winProbability = Math.round(Math.min(92, Math.max(28, winProbRaw + factorImpact * 0.5)));
```

Replace with:
```ts
  // Win probability — blended L5/L10 hit rate anchor, consistency-dampened,
  // trend-nudged, then factor-adjusted at half weight.
  const sideHitRate10 = isOver ? hitRate10 : 1 - hitRate10;
  const sideHitRate5  = isOver ? hitRate5  : 1 - hitRate5;

  // Blend: weight recent form (L5) at 60%, season form (L10) at 40%.
  // This makes the model more responsive to hot/cold streaks.
  const blendedHitRate = sideHitRate5 * 0.6 + sideHitRate10 * 0.4;

  // Consistency penalty: erratic players get their probability pulled toward 50.
  // A player with consistency=0.4 (high variance) gets 70% weight on blended rate;
  // a consistent player (consistency=0.9) gets full 100% weight.
  const consistencyWeight = 0.7 + consistency * 0.3;
  let winProbRaw = 50 + (blendedHitRate * 100 - 50) * consistencyWeight;

  // Trend nudge: stronger signal than before (±4 instead of ±3)
  if ((trend === "up"   && isOver)  || (trend === "down" && !isOver)) winProbRaw += 4;
  if ((trend === "down" && isOver)  || (trend === "up"   && !isOver)) winProbRaw -= 4;

  const factors: PropFactors = {
    weather: input.weatherFactor,
    opponent: input.opponentFactor,
    h2h: input.h2hFactor,
  };

  // Factor impact: full weight for H2H (real matchup data) vs half for opponent rank.
  // Previously all factors were at half weight equally.
  const factorImpact =
    (factors.weather?.impact ?? 0) * 0.5 +
    factors.opponent.impact * 0.5 +
    factors.h2h.impact * 0.75;   // H2H is the most predictive real signal

  // Tighter clamp: no prop can claim below 32% or above 88% confidence.
  // 92% was mathematically possible but misleading to users.
  const winProbability = Math.round(Math.min(88, Math.max(32, winProbRaw + factorImpact)));
```

---

## PATCH 4 — Sharpen the edge score thresholds for recommendation tiers

The current thresholds (8.0 for Strong, 6.5 for Lean) are too generous —
too many props reach "Strong Play" on weak data.

Find:
```ts
  if (edgeScore >= 8 && isOver) { recommendation = "Strong Over"; action = "Strong Play"; }
  else if (edgeScore >= 8 && !isOver) { recommendation = "Strong Under"; action = "Strong Play"; }
  else if (edgeScore >= 6.5 && isOver) { recommendation = "Lean Over"; action = "Lean"; }
  else if (edgeScore >= 6.5 && !isOver) { recommendation = "Lean Under"; action = "Lean"; }
  else if (edgeScore < 4.5 && Math.abs(lineGap) < sd * 0.1) {
    recommendation = isOver ? "Lean Under" : "Lean Over";
    action = "Trap Line";
  } else {
    recommendation = "Avoid";
    action = "Avoid";
  }
```

Replace with:
```ts
  // Tightened thresholds — fewer but higher-quality Strong Plays.
  // A "Strong Play" should mean real edge, not just a decent edgeScore.
  // Also require winProbability >= 68 for Strong (prevents high-edge low-prob combos).
  const isHighConf = winProbability >= 68;
  if (edgeScore >= 8.0 && isOver  && isHighConf) { recommendation = "Strong Over";  action = "Strong Play"; }
  else if (edgeScore >= 8.0 && !isOver && isHighConf) { recommendation = "Strong Under"; action = "Strong Play"; }
  else if (edgeScore >= 6.5 && isOver)  { recommendation = "Lean Over";   action = "Lean"; }
  else if (edgeScore >= 6.5 && !isOver) { recommendation = "Lean Under";  action = "Lean"; }
  else if (edgeScore < 4.5 && Math.abs(lineGap) < sd * 0.1) {
    recommendation = isOver ? "Lean Under" : "Lean Over";
    action = "Trap Line";
  } else {
    recommendation = "Avoid";
    action = "Avoid";
  }
```

---

## PATCH 5 — Improve reasoning text to be human-readable

Find:
```ts
  const reasoning = `Real last-${last10.length} avg ${avg10.toFixed(1)} ${template.unit}, last-5 ${avg5.toFixed(1)} (model line ${line}). ${factors.opponent.note} ${factors.weather ? factors.weather.note + " " : ""}${factors.h2h.note}`;
```

Replace with:
```ts
  const sideWord = isOver ? "Over" : "Under";
  const trendPhrase = trend === "up"
    ? "trending up over last 5"
    : trend === "down"
    ? "trending down over last 5"
    : "form is flat";
  const hitPct = Math.round((isOver ? hitRate5 : 1 - hitRate5) * 100);
  const reasoning = [
    `Cleared this line in ${hitPct}% of last ${last5.length} games (avg ${avg5.toFixed(1)} ${template.unit}, line ${line}).`,
    `Season avg ${avg10.toFixed(1)}, ${trendPhrase}.`,
    factors.opponent.note,
    factors.weather ? factors.weather.note : null,
    factors.h2h.meetings > 0 ? factors.h2h.note : null,
  ].filter(Boolean).join(" ");
```

---

## PATCH 6 — Improve pickBestProp to prefer winProbability + volume together

Find `pickBestProp` and replace its `best` comparator:

```ts
  const best = (arr: PlayerProp[]) =>
    arr.reduce((b, p) => {
      const wB = b.winProbability * tierWeights[classifyTier(b)];
      const wP = p.winProbability * tierWeights[classifyTier(p)];
      return wP > wB ? p : b;
    });
```

Replace with:
```ts
  // Score = winProbability × tier weight × volume bonus.
  // Props with line >= 2 get a 5% boost so high-volume picks
  // (e.g. 22.5 Points) beat tiny-line props (e.g. 0.5 Home Runs)
  // when both have similar win rates.
  const score = (p: PlayerProp) =>
    p.winProbability *
    tierWeights[classifyTier(p)] *
    (p.line >= 2 ? 1.05 : 1.0);

  const best = (arr: PlayerProp[]) =>
    arr.reduce((b, p) => (score(p) > score(b) ? p : b));
```

---

## PATCH 7 — Increase player counts per game

More star players = better board. Find in `processNbaGame`:
```ts
  const awayPicks = pickNbaPlayers(awayRoster, game.awayTeam.abbreviation, 4);
  const homePicks = pickNbaPlayers(homeRoster, game.homeTeam.abbreviation, 4);
```

Replace with:
```ts
  // 5 players per team (was 4) — surfaces more star/starter options per game
  const awayPicks = pickNbaPlayers(awayRoster, game.awayTeam.abbreviation, 5);
  const homePicks = pickNbaPlayers(homeRoster, game.homeTeam.abbreviation, 5);
```

Find in `processMlbGame`:
```ts
  const awayBatters = pickMlbPlayers(awayRoster, game.awayTeam.abbreviation, 6, ...);
  const homeBatters = pickMlbPlayers(homeRoster, game.homeTeam.abbreviation, 6, ...);
```

Replace both `6` values with `7`:
```ts
  const awayBatters = pickMlbPlayers(awayRoster, game.awayTeam.abbreviation, 7, ...);
  const homeBatters = pickMlbPlayers(homeRoster, game.homeTeam.abbreviation, 7, ...);
```

---

## Summary of what these patches do

| Patch | Problem fixed | User impact |
|---|---|---|
| 1 | Removed unavailable prop types (SB, 1B, 2B, K) | Only real PrizePicks/DK lines shown |
| 2 | Raised minimum sample/volume gate | No more 0.5-line garbage props |
| 3 | Better winProb formula (L5 weighted, tighter clamp) | 32–88% range, more accurate confidence |
| 4 | Strong Play requires winProb ≥ 68% | Fewer but higher-quality Strong plays |
| 5 | Human-readable reasoning | "Cleared this line in 73% of last 5" |
| 6 | Volume bonus in pickBestProp | High-volume props beat tiny-line props |
| 7 | 5 NBA players per team (was 4) | More star/starter options surfaced |
