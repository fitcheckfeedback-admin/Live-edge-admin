# Backend Upgrade — Implementation Guide

## Files to replace (drop-in)

| File in this zip | Replace in your project |
|---|---|
| `backend/routes/props.ts` | `artifacts/api-server/src/routes/props.ts` |
| `backend/routes/alerts.ts` | `artifacts/api-server/src/routes/alerts.ts` |
| `backend/routes/liveEdge.ts` | `artifacts/api-server/src/routes/liveEdge.ts` |

## File to patch manually

See `backend/PROPS_GENERATOR_PATCH.md` — 4 small targeted edits to
`artifacts/api-server/src/lib/propsGenerator.ts` and `src/app.ts`.

---

## What changed in each file

### props.ts
- Added `ALLOWED_PROP_TYPES` — only props actually offered on PrizePicks,
  DraftKings, Underdog make it through. Obscure/unavailable stat types are
  silently dropped.
- `GET /api/props/best` now cross-references the live game list and strips
  props belonging to **finished games** before responding.
- New `?minWinProb=65` query param — the Betting Edge screen uses this to
  request only 65%+ confidence picks without client-side filtering.
- `X-Cache-Age-Seconds` response header — lets the client know how fresh
  the data is.
- `POST /api/props/refresh` — new endpoint. The manual refresh button on
  the Edge Board hits this to bust the cache, then immediately kicks off
  a background warm-up fetch so the next GET is fast.
- `GET /api/dashboard/summary` — now applies the same allowed-type and
  final-game filters so the stats strip on the home screen reflects only
  real, available picks.

### alerts.ts
- Alerts older than **8 hours** are hidden from the response (not deleted
  from DB — safe to revert).
- New `propAlerts` field in the response body — a fresh list of rich prop
  objects generated directly from the prop engine, each enriched with full
  game context (team logos, score, period, clock). The frontend
  `alerts.tsx` already uses this field via `propsData` from `useGetBestProps`
  — no schema change needed on the client.
- `DELETE /api/alerts/stale` — housekeeping endpoint removes alerts older
  than 24h. Called automatically by the app.ts patch.
- Negative IDs for synthetic prop alerts so `POST /api/alerts/:id/read`
  handles them gracefully without a DB lookup.

### liveEdge.ts
- Added `?sport=NBA|MLB` filter so the frontend sport tabs actually filter
  server-side instead of fetching everything and filtering client-side.
- **"Avoid" recommendations are excluded** — only `Lean` and `Strong` edges
  reach the client. No point showing a live edge that says "Avoid."

### propsGenerator.ts patches
1. TTL 60s → 30s for fresher data during active game windows.
2. Final games excluded at the `eligible` filter — no wasted computation
   generating props for games that already ended.
3. Live edges sorted: Strong first, then Lean, then by edge magnitude.
   Cap raised 12 → 15 for busy multi-game windows.
4. Nightly alert cleanup wired into app.ts startup.

---

## Testing checklist

After deploying:
1. `GET /api/props/best?minWinProb=65` — should return only high-confidence picks
2. `GET /api/props/best` — no props for finished games in the response
3. `GET /api/alerts` — check `propAlerts` array in response, should have game context
4. `GET /api/live-edge` — no "Avoid" recommendations
5. `GET /api/live-edge?sport=NBA` — only NBA edges
6. `POST /api/props/refresh` — returns `{ cleared: true }`
